#!/bin/sh
noop injection.Injection --server http://google.com